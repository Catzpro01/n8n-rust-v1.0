//! Disk-backed `SpillStore` and blob storage. Implements kernel data contracts.
//!
//! Production home of `FileSpillStore`, moved here from
//! `crates/kernel/examples/spill_bench.rs` per SINTESIS-SPILLSTORE §6.1 step 2.
//! The benchmark keeps existing but calls this implementation — never a copy.
//!
//! Edge rule (audit A-05): this crate depends on `kernel` ONLY (plus external
//! hash crates). It stays runtime-agnostic like the kernel: synchronous
//! `std::fs` I/O inside `async fn` (callers drive it with any executor).

#![forbid(unsafe_code)]

pub mod spill;

pub use spill::FileSpillStore;
