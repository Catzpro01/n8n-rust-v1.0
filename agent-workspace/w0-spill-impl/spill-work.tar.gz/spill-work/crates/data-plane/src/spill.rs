//! `FileSpillStore` — real disk I/O with a real offset index.
//!
//! # On-disk format v1
//!
//! ```text
//! offset 0:  magic[4] = "SPL1" | version[1] = 0x01 | reserved[3] = 0
//! offset 8:  record 0: len[8 LE] payload[len]   (payload = JSON item bytes)
//!            record 1: len[8 LE] payload[len]
//!            ...
//! ```
//!
//! * `magic` is checked on **every** read entry point (`InvalidMagic`).
//! * `layer0_checksum` (SHA-256 over **all** file bytes, header included) is
//!   verified only by explicit `verify_integrity` (`ChecksumMismatch`).
//!   Reads detect truncation (`OffsetOutOfRange`) and undecodable records
//!   (`Codec`), but a corruption that still decodes as valid JSON is silent
//!   until the next explicit verify — a documented W0 limitation; the engine
//!   must schedule periodic/audit verification (later wave).
//! * `casd_hash` (BLAKE3 over the same bytes) is identity for CASD
//!   deduplication, never an integrity signal.
//! * Both hashes stream per item during write: transient peak ≈ 2 KB
//!   (112 B SHA-256 + 1920 B BLAKE3, agent10-measured) — O(1) in spill size,
//!   inside the locked 4 KB hash budget. The 256 KB `BufWriter` is pre-existing
//!   I/O buffering (Governor D72 domain), not hash transient.
//! * Files are created mode `0600` via `OpenOptions::mode` (constructor
//!   enforcement, umask-independent) per SEC-07.

use async_trait::async_trait;
use blake3::Hasher as Blake3Hasher;
use kernel::error::KernelError;
use kernel::id::SpillPath;
use kernel::item::{Item, SpillCodec, SpillStore, SpillWriter, SpilledList};
use sha2::{Digest, Sha256};
use std::collections::HashMap;
use std::fs::{File, OpenOptions};
use std::io::{BufWriter, Read, Seek, SeekFrom, Write};
use std::path::PathBuf;
use std::sync::{Arc, Mutex};

/// File magic (agent2 #256, approved agent5). Wrong magic = `InvalidMagic`.
pub const SPILL_MAGIC: [u8; 4] = *b"SPL1";
/// Format version. Only v1 is readable; anything else is fail-closed.
pub const SPILL_VERSION: u8 = 1;
/// Header length: magic[4] + version[1] + reserved[3].
pub const HEADER_LEN: u64 = 8;
/// Streaming read buffer for `verify_integrity` (2 KB + 112 B hasher < 4 KB).
const VERIFY_BUF: usize = 2048;

fn hex(bytes: &[u8]) -> String {
    const H: &[u8; 16] = b"0123456789abcdef";
    let mut s = String::with_capacity(bytes.len() * 2);
    for &b in bytes {
        s.push(H[(b >> 4) as usize] as char);
        s.push(H[(b & 15) as usize] as char);
    }
    s
}

struct Entry {
    /// Byte offset of each item in the spill file (8 bytes per item in RAM,
    /// payload stays on disk).
    offsets: Vec<u64>,
    file: File,
}

type Entries = Arc<Mutex<HashMap<String, Entry>>>;

pub struct FileSpillStore {
    dir: PathBuf,
    next_id: Mutex<u64>,
    entries: Entries,
}

impl FileSpillStore {
    /// Open (creating) a spill root. Flat layout: `spill-<N>.bin` directly
    /// under `dir`. For per-execution GC use [`FileSpillStore::for_execution`].
    pub fn new(dir: impl Into<PathBuf>) -> std::io::Result<Self> {
        let dir = dir.into();
        std::fs::create_dir_all(&dir)?;
        Ok(Self {
            dir,
            next_id: Mutex::new(0),
            entries: Arc::new(Mutex::new(HashMap::new())),
        })
    }

    /// Open a store scoped to one execution (`root/execution_id/`). Only an
    /// execution-scoped store can [`FileSpillStore::gc_execution`] — the flat
    /// layout carries no execution namespace, so GC there would be guessing.
    pub fn for_execution(root: impl Into<PathBuf>, execution_id: &str) -> std::io::Result<Self> {
        assert_no_traversal(execution_id)
            .map_err(|m| std::io::Error::new(std::io::ErrorKind::InvalidInput, m))?;
        Self::new(root.into().join(execution_id))
    }

    /// Delete every spill file owned by this execution-scoped store, drop its
    /// index entries, and remove the directory. Returns files deleted.
    ///
    /// Callers must respect audit A-21: never GC an execution that is not
    /// terminal (RUNNING / WAITING / PAUSED handles must not lose files).
    pub fn gc_execution(&self) -> Result<u64, KernelError> {
        let mut count = 0u64;
        let rd = std::fs::read_dir(&self.dir).map_err(io_err)?;
        for ent in rd {
            let ent = ent.map_err(io_err)?;
            let p = ent.path();
            let is_spill = p
                .file_name()
                .and_then(|n| n.to_str())
                .map(|n| n.starts_with("spill-") && n.ends_with(".bin"))
                .unwrap_or(false);
            if is_spill {
                std::fs::remove_file(&p).map_err(io_err)?;
                count += 1;
            }
        }
        self.entries.lock().unwrap().clear();
        // Best effort: dir may hold foreign files; only remove when empty.
        let _ = std::fs::remove_dir(&self.dir);
        Ok(count)
    }

    fn path_for(&self, name: &str) -> PathBuf {
        self.dir.join(name)
    }

    fn alloc_name(&self) -> String {
        let mut next = self.next_id.lock().unwrap();
        *next += 1;
        format!("spill-{}.bin", *next)
    }

    /// RAM held by the index for one handle.
    pub fn index_bytes(&self, handle: &SpilledList) -> usize {
        self.entries
            .lock()
            .unwrap()
            .get(handle.path.as_str())
            .map(|e| e.offsets.len() * std::mem::size_of::<u64>())
            .unwrap_or(0)
    }
}

fn assert_no_traversal(id: &str) -> Result<(), String> {
    if id.is_empty() || id == "." || id == ".." || id.contains('/') || id.contains('\\') {
        return Err(format!("unsafe execution_id for path scope: {id:?}"));
    }
    Ok(())
}

fn io_err(e: std::io::Error) -> KernelError {
    KernelError::SpillIo {
        message: e.to_string(),
    }
}

/// Read-path error mapping: an unexpected EOF means the file is shorter than
/// its index claims — corruption (`OffsetOutOfRange`), not infra noise.
/// Anything else stays `SpillIo` (node FAILED + retry policy per E_SPILL_IO).
fn read_err(e: std::io::Error, what: &str) -> KernelError {
    if e.kind() == std::io::ErrorKind::UnexpectedEof {
        KernelError::OffsetOutOfRange {
            message: format!("{what}: unexpected EOF"),
        }
    } else {
        io_err(e)
    }
}

/// Serialize one item to the on-disk record payload.
fn encode(it: &Item) -> Result<Vec<u8>, KernelError> {
    serde_json::to_vec(it).map_err(|e| KernelError::Codec {
        codec: "json",
        reason: e.to_string(),
    })
}

fn decode(buf: &[u8]) -> Result<Item, KernelError> {
    serde_json::from_slice(buf).map_err(|e| KernelError::Codec {
        codec: "json",
        reason: e.to_string(),
    })
}

/// Create with `0600` enforced in the constructor (SEC-07): `mode` applies at
/// creation time, so the result is umask-independent. No create-then-chmod
/// window where the file is world-readable.
fn open_rw(path: &PathBuf) -> Result<File, KernelError> {
    let mut opts = OpenOptions::new();
    opts.create(true).write(true).read(true).truncate(true);
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        opts.mode(0o600);
    }
    opts.open(path).map_err(io_err)
}

/// Verify the 8-byte header. Leaves the cursor position unspecified; callers
/// always seek explicitly afterwards.
fn check_magic(file: &mut File, name: &str) -> Result<(), KernelError> {
    file.seek(SeekFrom::Start(0)).map_err(io_err)?;
    let mut hdr = [0u8; HEADER_LEN as usize];
    file.read_exact(&mut hdr)
        .map_err(|e| read_err(e, &format!("spill {name}: header")))?;
    if hdr[0..4] != SPILL_MAGIC {
        return Err(KernelError::InvalidMagic {
            expected: hex(&SPILL_MAGIC),
            got: hex(&hdr[0..4]),
        });
    }
    if hdr[4] != SPILL_VERSION {
        return Err(KernelError::Invalid {
            message: format!(
                "spill {name}: unsupported version {}, want {}",
                hdr[4], SPILL_VERSION
            ),
        });
    }
    Ok(())
}

fn lock_entry<'a>(
    entries: &'a mut std::sync::MutexGuard<'_, HashMap<String, Entry>>,
    handle: &SpilledList,
) -> Result<&'a mut Entry, KernelError> {
    entries
        .get_mut(handle.path.as_str())
        .ok_or_else(|| KernelError::SpillIo {
            message: format!("no such spill file: {}", handle.path),
        })
}

#[async_trait]
impl SpillStore for FileSpillStore {
    async fn write(&self, items: &[Item]) -> Result<SpilledList, KernelError> {
        // Convenience path: reuse the streaming writer so there is exactly one
        // implementation of the file format.
        let mut w = self.writer().await?;
        w.push(items).await?;
        w.finish().await
    }

    async fn read_at(&self, handle: &SpilledList, index: usize) -> Result<Item, KernelError> {
        let mut entries = self.entries.lock().unwrap();
        let entry = lock_entry(&mut entries, handle)?;
        check_magic(&mut entry.file, handle.path.as_str())?;

        let &off = entry
            .offsets
            .get(index)
            .ok_or(KernelError::IndexOutOfBounds {
                index,
                len: entry.offsets.len(),
            })?;

        entry.file.seek(SeekFrom::Start(off)).map_err(io_err)?;
        let mut lenbuf = [0u8; 8];
        entry
            .file
            .read_exact(&mut lenbuf)
            .map_err(|e| read_err(e, &format!("spill {} index {index}", handle.path)))?;
        let len = u64::from_le_bytes(lenbuf) as usize;

        let mut buf = vec![0u8; len];
        entry
            .file
            .read_exact(&mut buf)
            .map_err(|e| read_err(e, &format!("spill {} index {index}", handle.path)))?;
        decode(&buf)
    }

    async fn read_range(
        &self,
        handle: &SpilledList,
        start: usize,
        len: usize,
    ) -> Result<Vec<Item>, KernelError> {
        // Sequential read: one seek, then stream the whole range. This is the
        // cursor hot path, so avoiding N seeks is what makes chunked iteration
        // cheaper than N random gets.
        let mut entries = self.entries.lock().unwrap();
        let entry = lock_entry(&mut entries, handle)?;
        check_magic(&mut entry.file, handle.path.as_str())?;

        let n = entry.offsets.len();
        if start >= n || len == 0 {
            return Ok(Vec::new());
        }
        let end = (start + len).min(n);
        let off = entry.offsets[start];
        entry.file.seek(SeekFrom::Start(off)).map_err(io_err)?;

        let file_len = entry.file.metadata().map(|m| m.len()).unwrap_or(0);
        let span = if end < n {
            (entry.offsets[end] - off) as usize
        } else {
            (file_len.saturating_sub(off)) as usize
        };

        let mut raw = vec![0u8; span];
        entry
            .file
            .read_exact(&mut raw)
            .map_err(|e| read_err(e, &format!("spill {} range", handle.path)))?;

        let mut out = Vec::with_capacity(end - start);
        let mut cur = 0usize;
        for i in start..end {
            if cur + 8 > raw.len() {
                return Err(KernelError::OffsetOutOfRange {
                    message: format!("spill {} record {i}: header past EOF", handle.path),
                });
            }
            let l = u64::from_le_bytes(raw[cur..cur + 8].try_into().unwrap()) as usize;
            cur += 8;
            if cur + l > raw.len() {
                return Err(KernelError::OffsetOutOfRange {
                    message: format!("spill {} record {i}: payload past EOF", handle.path),
                });
            }
            out.push(decode(&raw[cur..cur + l])?);
            cur += l;
        }
        Ok(out)
    }

    async fn read_all(&self, handle: &SpilledList) -> Result<Vec<Item>, KernelError> {
        self.read_range(handle, 0, handle.len as usize).await
    }

    async fn delete(&self, handle: &SpilledList) -> Result<(), KernelError> {
        self.entries.lock().unwrap().remove(handle.path.as_str());
        let p = self.path_for(handle.path.as_str());
        if p.exists() {
            std::fs::remove_file(p).map_err(io_err)?;
        }
        Ok(())
    }

    fn disk_footprint(&self, handle: &SpilledList) -> u64 {
        handle.total_bytes
    }

    async fn verify_integrity(&self, handle: &SpilledList) -> Result<bool, KernelError> {
        let expected = handle.layer0_checksum.ok_or_else(|| KernelError::Invalid {
            message: "legacy spill: no layer0_checksum recorded".to_string(),
        })?;
        // Fresh handle: proves at-rest bytes, never disturbs the live cursor.
        let path = self.path_for(handle.path.as_str());
        let mut file = File::open(&path).map_err(|e| {
            if e.kind() == std::io::ErrorKind::NotFound {
                KernelError::SpillIo {
                    message: format!("no such spill file: {}", handle.path),
                }
            } else {
                io_err(e)
            }
        })?;
        check_magic(&mut file, handle.path.as_str())?;
        file.seek(SeekFrom::Start(0)).map_err(io_err)?;
        let mut h = Sha256::new();
        let mut buf = vec![0u8; VERIFY_BUF];
        loop {
            let n = file.read(&mut buf).map_err(io_err)?;
            if n == 0 {
                break;
            }
            h.update(&buf[..n]);
        }
        let actual: [u8; 32] = h.finalize().into();
        if actual != expected {
            return Err(KernelError::ChecksumMismatch {
                expected: hex(&expected),
                actual: hex(&actual),
            });
        }
        Ok(true)
    }

    async fn writer(&self) -> Result<Box<dyn SpillWriter>, KernelError> {
        let name = self.alloc_name();
        let fs_path = self.path_for(&name);
        let file = open_rw(&fs_path)?;
        let mut w = BufWriter::with_capacity(256 * 1024, file);
        // Header first; it is part of the hashed bytes.
        let mut hdr = [0u8; HEADER_LEN as usize];
        hdr[0..4].copy_from_slice(&SPILL_MAGIC);
        hdr[4] = SPILL_VERSION;
        let mut sha256 = Sha256::new();
        let mut blake3 = Blake3Hasher::new();
        sha256.update(hdr);
        blake3.update(&hdr);
        w.write_all(&hdr).map_err(io_err)?;
        Ok(Box::new(FileSpillWriter {
            logical: name,
            fs_path,
            w: Some(w),
            sha256: Some(sha256),
            blake3: Some(blake3),
            offsets: Vec::new(),
            pos: HEADER_LEN,
            total: 0,
            finished: false,
            entries: Arc::clone(&self.entries),
        }))
    }
}

struct FileSpillWriter {
    logical: String,
    fs_path: PathBuf,
    /// `Option` so `finish` can move the parts out (`Drop` forbids moving
    /// fields out of `self` directly, E0509).
    w: Option<BufWriter<File>>,
    sha256: Option<Sha256>,
    blake3: Option<Blake3Hasher>,
    offsets: Vec<u64>,
    pos: u64,
    total: u64,
    finished: bool,
    entries: Entries,
}

#[async_trait]
impl SpillWriter for FileSpillWriter {
    async fn push(&mut self, items: &[Item]) -> Result<(), KernelError> {
        if self.finished {
            return Err(KernelError::Invalid {
                message: "push() called after finish()".to_string(),
            });
        }
        let w = self.w.as_mut().ok_or(KernelError::Invalid {
            message: "writer already finished".to_string(),
        })?;
        let sha256 = self.sha256.as_mut().ok_or(KernelError::Invalid {
            message: "writer already finished".to_string(),
        })?;
        let blake3 = self.blake3.as_mut().ok_or(KernelError::Invalid {
            message: "writer already finished".to_string(),
        })?;
        for it in items {
            let bytes = encode(it)?;
            let len = bytes.len() as u64;
            let lenbytes = len.to_le_bytes();
            // Stream into both hashers: no extra buffer beyond the record
            // bytes that already exist. Transient ≈ 2 KB, O(1) in spill size.
            sha256.update(lenbytes);
            sha256.update(&bytes);
            blake3.update(&lenbytes);
            blake3.update(&bytes);
            w.write_all(&lenbytes)
                .and_then(|_| w.write_all(&bytes))
                .map_err(io_err)?;
            self.offsets.push(self.pos);
            self.pos += 8 + len;
            self.total += len;
        }
        Ok(())
    }

    async fn finish(mut self: Box<Self>) -> Result<SpilledList, KernelError> {
        let mut bw = self.w.take().ok_or(KernelError::Invalid {
            message: "finish() called twice".to_string(),
        })?;
        bw.flush().map_err(io_err)?;
        let file = bw.into_inner().map_err(|e| io_err(e.into_error()))?;
        file.sync_all().map_err(io_err)?;
        let sha256 = self.sha256.take().ok_or(KernelError::Invalid {
            message: "finish() called twice".to_string(),
        })?;
        let blake3 = self.blake3.take().ok_or(KernelError::Invalid {
            message: "finish() called twice".to_string(),
        })?;
        let layer0_checksum: [u8; 32] = sha256.finalize().into();
        let casd_hash: [u8; 32] = *blake3.finalize().as_bytes();

        let count = self.offsets.len() as u32;
        self.entries.lock().unwrap().insert(
            self.logical.clone(),
            Entry {
                offsets: std::mem::take(&mut self.offsets),
                file,
            },
        );
        self.finished = true;

        Ok(SpilledList {
            path: SpillPath::new(self.logical.clone()),
            len: count,
            total_bytes: self.total,
            codec: SpillCodec::Json,
            layer0_checksum: Some(layer0_checksum),
            casd_hash: Some(casd_hash),
        })
    }

    fn pushed(&self) -> u32 {
        self.offsets.len() as u32
    }
}

/// Honour the trait contract: an unfinished writer must not leak a partial file.
impl Drop for FileSpillWriter {
    fn drop(&mut self) {
        if !self.finished {
            let _ = std::fs::remove_file(&self.fs_path);
        }
    }
}
