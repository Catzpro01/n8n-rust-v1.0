//! W0-SPILL-IMPL acceptance tests: the REAL `FileSpillStore` on disk.
//!
//! Covers SINTESIS-SPILLSTORE §6.1 step 4 (real store, `umask 000`,
//! 1-byte corruption → `ChecksumMismatch`) plus the G-C7 specific errors
//! (`InvalidMagic`, `OffsetOutOfRange`) and GC/drop lifecycle.
//!
//! Runtime-agnostic like the kernel: plain `#[test]` + a spin `block_on`.

use data_plane::spill::{HEADER_LEN, SPILL_MAGIC, SPILL_VERSION};
use data_plane::FileSpillStore;
use kernel::error::KernelError;
use kernel::item::{Item, SpillCodec, SpillStore, SpilledList};
use serde_json::json;
use std::fs::OpenOptions;
use std::io::{Read, Seek, SeekFrom, Write};
use std::path::PathBuf;
use std::sync::atomic::{AtomicU64, Ordering};

fn block_on<F: std::future::Future>(fut: F) -> F::Output {
    use std::sync::atomic::AtomicBool;
    use std::task::{Context, Poll, Wake};

    struct Spin(AtomicBool);
    impl Wake for Spin {
        fn wake(self: std::sync::Arc<Self>) {
            self.0.store(true, Ordering::SeqCst);
        }
    }

    let waker = std::sync::Arc::new(Spin(AtomicBool::new(false))).into();
    let mut cx = Context::from_waker(&waker);
    let mut fut = Box::pin(fut);
    loop {
        match fut.as_mut().poll(&mut cx) {
            Poll::Ready(v) => return v,
            Poll::Pending => std::thread::yield_now(),
        }
    }
}

static NEXT_DIR: AtomicU64 = AtomicU64::new(0);

fn fresh_dir() -> PathBuf {
    let n = NEXT_DIR.fetch_add(1, Ordering::SeqCst);
    let d = std::env::temp_dir().join(format!(
        "spill-test-{}-{}-{}",
        std::process::id(),
        n,
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));
    std::fs::create_dir_all(&d).unwrap();
    d
}

fn item(i: u64) -> Item {
    Item::new(json!({"id": i, "name": format!("row-{i}"), "pad": "x".repeat(64)}))
}

fn items(n: u64) -> Vec<Item> {
    (0..n).map(item).collect()
}

fn spill_file(dir: &std::path::Path, h: &SpilledList) -> PathBuf {
    dir.join(h.path.as_str())
}

#[test]
fn roundtrip_and_handle_fields() {
    let dir = fresh_dir();
    let store = FileSpillStore::new(&dir).unwrap();
    let items = items(50);
    let h = block_on(store.write(&items)).unwrap();

    assert_eq!(h.len, 50);
    assert_eq!(h.codec, SpillCodec::Json);
    assert!(h.total_bytes > 0);
    // Dual hash present and distinct (different algorithms).
    let (Some(sha), Some(b3)) = (h.layer0_checksum, h.casd_hash) else {
        panic!("both hashes must be computed");
    };
    assert_ne!(sha, b3);
    // Header on disk.
    let mut f = std::fs::File::open(spill_file(&dir, &h)).unwrap();
    let mut hdr = [0u8; 8];
    f.read_exact(&mut hdr).unwrap();
    assert_eq!(&hdr[0..4], &SPILL_MAGIC);
    assert_eq!(hdr[4], SPILL_VERSION);

    assert_eq!(block_on(store.read_at(&h, 0)).unwrap().json, items[0].json);
    assert_eq!(
        block_on(store.read_at(&h, 49)).unwrap().json,
        items[49].json
    );
    let r = block_on(store.read_range(&h, 10, 5)).unwrap();
    assert_eq!(r.len(), 5);
    assert_eq!(r[0].json, items[10].json);
    assert_eq!(block_on(store.read_all(&h)).unwrap().len(), 50);
    assert!(block_on(store.verify_integrity(&h)).unwrap());
    assert_eq!(store.index_bytes(&h), 50 * 8);

    block_on(store.delete(&h)).unwrap();
    assert!(!spill_file(&dir, &h).exists());
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn one_byte_corruption_detected_by_verify() {
    let dir = fresh_dir();
    let store = FileSpillStore::new(&dir).unwrap();
    let h = block_on(store.write(&items(10))).unwrap();
    assert!(block_on(store.verify_integrity(&h)).unwrap());

    // Flip one byte inside record 3's JSON string payload (stays valid JSON).
    let p = spill_file(&dir, &h);
    let mut f = OpenOptions::new().read(true).write(true).open(&p).unwrap();
    // Record 0 starts at HEADER_LEN; walk two records to land inside record 2+.
    let mut off = HEADER_LEN;
    for _ in 0..2 {
        f.seek(SeekFrom::Start(off)).unwrap();
        let mut lb = [0u8; 8];
        f.read_exact(&mut lb).unwrap();
        off += 8 + u64::from_le_bytes(lb);
    }
    // Inside the payload: find a ':' then flip the next byte's case bit.
    f.seek(SeekFrom::Start(off + 8)).unwrap();
    let mut payload = vec![0u8; 64];
    f.read_exact(&mut payload).unwrap();
    let pos = payload.iter().position(|&b| b == b'"').unwrap();
    payload[pos] = b'\'';
    f.seek(SeekFrom::Start(off + 8)).unwrap();
    f.write_all(&payload).unwrap();
    drop(f);

    match block_on(store.verify_integrity(&h)) {
        Err(KernelError::ChecksumMismatch { .. }) => {}
        other => panic!("want ChecksumMismatch, got {other:?}"),
    }
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn bad_magic_fail_closed() {
    let dir = fresh_dir();
    let store = FileSpillStore::new(&dir).unwrap();
    let h = block_on(store.write(&items(5))).unwrap();

    let p = spill_file(&dir, &h);
    let mut f = OpenOptions::new().write(true).open(&p).unwrap();
    f.write_all(b"NOPE").unwrap();
    drop(f);

    match block_on(store.read_at(&h, 0)) {
        Err(KernelError::InvalidMagic { .. }) => {}
        other => panic!("want InvalidMagic, got {other:?}"),
    }
    match block_on(store.verify_integrity(&h)) {
        Err(KernelError::InvalidMagic { .. }) => {}
        other => panic!("want InvalidMagic on verify, got {other:?}"),
    }
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn truncation_is_offset_out_of_range() {
    let dir = fresh_dir();
    let store = FileSpillStore::new(&dir).unwrap();
    let h = block_on(store.write(&items(20))).unwrap();

    // Truncate mid-file: header intact, records cut.
    let p = spill_file(&dir, &h);
    let f = OpenOptions::new().write(true).open(&p).unwrap();
    f.set_len(HEADER_LEN + 30).unwrap();
    drop(f);

    match block_on(store.read_at(&h, 19)) {
        Err(KernelError::OffsetOutOfRange { .. }) => {}
        other => panic!("want OffsetOutOfRange, got {other:?}"),
    }
    match block_on(store.read_range(&h, 0, 20)) {
        Err(KernelError::OffsetOutOfRange { .. }) => {}
        other => panic!("want OffsetOutOfRange on range, got {other:?}"),
    }
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn index_out_of_bounds_unchanged() {
    let dir = fresh_dir();
    let store = FileSpillStore::new(&dir).unwrap();
    let h = block_on(store.write(&items(3))).unwrap();
    match block_on(store.read_at(&h, 3)) {
        Err(KernelError::IndexOutOfBounds { index: 3, len: 3 }) => {}
        other => panic!("want IndexOutOfBounds, got {other:?}"),
    }
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn legacy_handle_verify_fails_explicit() {
    let dir = fresh_dir();
    let store = FileSpillStore::new(&dir).unwrap();
    let h = block_on(store.write(&items(2))).unwrap();
    let legacy = SpilledList {
        path: h.path.clone(),
        len: h.len,
        total_bytes: h.total_bytes,
        codec: h.codec,
        layer0_checksum: None,
        casd_hash: None,
    };
    match block_on(store.verify_integrity(&legacy)) {
        Err(KernelError::Invalid { message }) => {
            assert!(message.contains("legacy"), "message: {message}");
        }
        other => panic!("want Invalid(legacy), got {other:?}"),
    }
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn spill_files_are_0600_umask_independent() {
    // SEC-07: constructor enforcement, proven under umask 000 (agent5).
    // umask is process-global: set 000, write, restore immediately, then assert.
    let prev = unsafe { libc::umask(0o000) };
    let dir = fresh_dir();
    let store = FileSpillStore::new(&dir).unwrap();
    let h = block_on(store.write(&items(2))).unwrap();
    unsafe {
        libc::umask(prev);
    }

    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let mode = std::fs::metadata(spill_file(&dir, &h))
            .unwrap()
            .permissions()
            .mode()
            & 0o777;
        assert_eq!(mode, 0o600, "spill file mode must be 0600 under umask 000");
    }
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn gc_execution_removes_only_own_files() {
    let root = fresh_dir();
    let store = FileSpillStore::for_execution(&root, "exec-9").unwrap();
    let h1 = block_on(store.write(&items(3))).unwrap();
    let _h2 = block_on(store.write(&items(4))).unwrap();
    // A foreign file must survive GC.
    std::fs::write(root.join("exec-9").join("keep.txt"), b"no").unwrap();

    let n = store.gc_execution().unwrap();
    assert_eq!(n, 2);
    assert!(!spill_file(&root.join("exec-9"), &h1).exists());
    assert!(root.join("exec-9").join("keep.txt").exists());
    // Index dropped: reads now fail as missing.
    assert!(block_on(store.read_at(&h1, 0)).is_err());
    // Traversal rejected.
    assert!(FileSpillStore::for_execution(&root, "../evil").is_err());
    std::fs::remove_dir_all(&root).unwrap();
}

#[test]
fn dropped_writer_leaves_no_file() {
    let dir = fresh_dir();
    let store = FileSpillStore::new(&dir).unwrap();
    {
        let mut w = block_on(store.writer()).unwrap();
        block_on(w.push(&items(5))).unwrap();
        assert_eq!(w.pushed(), 5);
        // Drop without finish.
    }
    let leftovers: Vec<_> = std::fs::read_dir(&dir).unwrap().collect();
    assert!(leftovers.is_empty(), "partial file leaked: {leftovers:?}");
    std::fs::remove_dir_all(&dir).unwrap();
}

#[test]
fn indexed_read_scales() {
    let dir = fresh_dir();
    let store = FileSpillStore::new(&dir).unwrap();
    let h = block_on(store.write(&items(5000))).unwrap();
    assert_eq!(
        block_on(store.read_at(&h, 4999)).unwrap().json["id"],
        json!(4999)
    );
    assert_eq!(store.index_bytes(&h), 5000 * 8);
    assert!(block_on(store.verify_integrity(&h)).unwrap());
    std::fs::remove_dir_all(&dir).unwrap();
}
