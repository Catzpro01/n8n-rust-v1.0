//! Empirical proof of the A-03 resolution.
//!
//! This turns "spill-to-disk keeps RAM bounded" from a design claim into a
//! measured number. It matters because the entire 2 GB VPS thesis (D3) rests on
//! it, and audit A-03 flagged that the blueprint asserted memory efficiency
//! without ever measuring it.
//!
//! Unlike the in-memory store in `tests/contract.rs`, `FileSpillStore` from
//! `data-plane` does **real disk I/O** with a real offset index — the same
//! production implementation the engine uses, not a copy. So this validates both the RAM claim and
//! that `SpillStore` is actually implementable against a filesystem as designed.
//!
//! ```text
//! cargo run --release --example spill_bench -- compare 2000000
//! cargo run --release --example spill_bench -- spilled 2000000
//! cargo run --release --example spill_bench -- inline  2000000
//! ```
//!
//! `compare` re-execs itself once per scenario in a **separate process**. That
//! is deliberate: `VmHWM` is a process-lifetime high-water mark and cannot be
//! reset, so measuring both scenarios in one process would report the inline
//! peak for both and quietly prove nothing.

use data_plane::FileSpillStore;
use kernel::item::{spill_from_iter, Item, ItemList, SpillPolicy, SpillStore};
use serde_json::json;
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Instant;

// ═══════════════════════════════════════════════════════════════════════════
// Minimal executor (kernel is runtime-agnostic; no tokio dependency)
// ═══════════════════════════════════════════════════════════════════════════

fn block_on<F: std::future::Future>(fut: F) -> F::Output {
    use std::sync::atomic::{AtomicBool, Ordering};
    use std::task::{Context, Poll, Wake};

    struct Spin(AtomicBool);
    impl Wake for Spin {
        fn wake(self: Arc<Self>) {
            self.0.store(true, Ordering::SeqCst);
        }
    }

    let spin = Arc::new(Spin(AtomicBool::new(true)));
    let waker: std::task::Waker = spin.clone().into();
    let mut cx = Context::from_waker(&waker);
    let mut fut = Box::pin(fut);
    loop {
        match fut.as_mut().poll(&mut cx) {
            Poll::Ready(v) => return v,
            Poll::Pending => {
                spin.0.store(false, Ordering::SeqCst);
                std::hint::spin_loop();
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Measurement
// ═══════════════════════════════════════════════════════════════════════════

fn proc_field(name: &str) -> u64 {
    let s = std::fs::read_to_string("/proc/self/status").unwrap_or_default();
    for line in s.lines() {
        if let Some(rest) = line.strip_prefix(name) {
            return rest
                .trim()
                .trim_end_matches("kB")
                .trim()
                .parse::<u64>()
                .unwrap_or(0)
                * 1024;
        }
    }
    0
}

fn rss() -> u64 {
    proc_field("VmRSS:")
}
fn peak_rss() -> u64 {
    proc_field("VmHWM:")
}
fn mb(b: u64) -> f64 {
    b as f64 / (1024.0 * 1024.0)
}

/// Thousands separator, id-ID style (1.000.000).
fn grouped(n: usize) -> String {
    let s = n.to_string();
    let bytes = s.as_bytes();
    let mut out = String::with_capacity(s.len() + s.len() / 3);
    for (i, b) in bytes.iter().enumerate() {
        if i > 0 && (bytes.len() - i) % 3 == 0 {
            out.push('.');
        }
        out.push(*b as char);
    }
    out
}

/// A realistic item: the shape an HTTP Request or Postgres node emits.
/// ~170 bytes of JSON — typical for API rows, CRM records, order lines.
fn make_item(i: usize) -> Item {
    Item::new(json!({
        "id": i,
        "email": format!("user{}@example.com", i),
        "name": format!("Customer {i}"),
        "amount_cents": (i * 37) % 100_000,
        "created_at": "2026-09-09T12:00:00Z",
        "status": if i % 3 == 0 { "active" } else { "pending" },
    }))
}

fn temp_dir(tag: &str) -> PathBuf {
    std::env::temp_dir().join(format!("spill-bench-{}-{}", tag, std::process::id()))
}

/// Spilled scenario.
///
/// Items are generated **lazily** and streamed straight to disk in batches, so
/// the full set is never resident. This is the honest version of the claim: it
/// is what a Postgres trigger or a paginated HTTP node actually does.
fn scenario_spilled(n: usize) -> Report {
    let dir = temp_dir("spilled");
    let store = FileSpillStore::new(&dir).expect("mkdir");

    let rss_before = rss();
    let t0 = Instant::now();
    let list = block_on(spill_from_iter(10_000, &store, (0..n).map(make_item))).expect("spill");
    let build = t0.elapsed();

    assert!(list.is_spilled(), "expected spill at n={}", n);
    let handle = match &list {
        ItemList::Spilled(h) => h.clone(),
        ItemList::Inline(_) => panic!("expected spilled"),
    };

    let (scan, processed, checksum) = scan_all(&list, &store);
    let random_access = timed(|| {
        let v = list.view(&store);
        block_on(v.get(n - 1)).expect("last")
    });

    let report = Report {
        mode: "SPILLED",
        n,
        items_processed: processed,
        checksum,
        logical_bytes: handle.total_bytes,
        index_bytes: store.index_bytes(&handle) as u64,
        struct_bytes: list.ram_footprint() as u64,
        rss_before,
        rss_after: rss(),
        peak_rss: peak_rss(),
        build,
        scan,
        random_access,
    };

    let _ = block_on(store.delete(&handle));
    let _ = std::fs::remove_dir_all(&dir);
    report
}

/// Inline scenario: everything resident, which is what n8n does today.
fn scenario_inline(n: usize) -> Report {
    let dir = temp_dir("inline");
    let store = FileSpillStore::new(&dir).expect("mkdir");
    let policy = SpillPolicy {
        max_inline_items: u32::MAX,
        max_inline_bytes: u64::MAX,
        max_inline_binary_bytes: u64::MAX,
    };

    let rss_before = rss();
    let t0 = Instant::now();
    // Materialize the full set first — this is the point of the comparison.
    let items: Vec<Item> = (0..n).map(make_item).collect();
    let logical_bytes: u64 = items.iter().map(|i| i.estimated_bytes() as u64).sum();
    let list = block_on(ItemList::from_vec(items, &policy, &store)).expect("inline");
    let build = t0.elapsed();

    assert!(!list.is_spilled(), "expected inline at n={}", n);

    let (scan, processed, checksum) = scan_all(&list, &store);
    let random_access = timed(|| {
        let v = list.view(&store);
        block_on(v.get(n - 1)).expect("last")
    });

    let report = Report {
        mode: "INLINE",
        n,
        items_processed: processed,
        checksum,
        logical_bytes,
        index_bytes: 0,
        struct_bytes: list.ram_footprint() as u64,
        rss_before,
        rss_after: rss(),
        peak_rss: peak_rss(),
        build,
        scan,
        random_access,
    };

    drop(list);
    let _ = std::fs::remove_dir_all(&dir);
    report
}

/// Walk every item through a cursor, the way a transform node would.
fn scan_all(list: &ItemList, store: &FileSpillStore) -> (std::time::Duration, usize, u64) {
    let view = list.view(store);
    let t = Instant::now();
    let mut processed = 0usize;
    let mut checksum: u64 = 0;
    let mut cur = view.cursor(1_000);
    while let Some(chunk) = block_on(cur.next_chunk()).expect("chunk") {
        for it in &chunk {
            checksum = checksum.wrapping_add(it.json["amount_cents"].as_u64().unwrap_or(0));
            processed += 1;
        }
    }
    (t.elapsed(), processed, checksum)
}

fn timed<F, R>(f: F) -> std::time::Duration
where
    F: FnOnce() -> R,
{
    let t = Instant::now();
    let _ = f();
    t.elapsed()
}

struct Report {
    mode: &'static str,
    n: usize,
    items_processed: usize,
    checksum: u64,
    logical_bytes: u64,
    index_bytes: u64,
    struct_bytes: u64,
    rss_before: u64,
    rss_after: u64,
    peak_rss: u64,
    build: std::time::Duration,
    scan: std::time::Duration,
    random_access: std::time::Duration,
}

impl Report {
    fn print(&self) {
        println!();
        println!("┌─ {} ─ {} items", self.mode, grouped(self.n));
        println!("│ payload (logical)    {:>9.1} MB", mb(self.logical_bytes));
        println!("│ RAM list structs     {:>9.1} MB", mb(self.struct_bytes));
        println!("│ RAM spill index      {:>9.1} MB", mb(self.index_bytes));
        println!("│ RSS at start         {:>9.1} MB", mb(self.rss_before));
        println!("│ RSS after full scan  {:>9.1} MB", mb(self.rss_after));
        println!("│ PEAK RSS (VmHWM)     {:>9.1} MB", mb(self.peak_rss));
        println!("│ build + spill        {:>9.3} s", self.build.as_secs_f64());
        println!("│ scan all items       {:>9.3} s", self.scan.as_secs_f64());
        println!(
            "│ random get(last)     {:>9.3} ms",
            self.random_access.as_secs_f64() * 1000.0
        );
        println!(
            "│ items processed      {:>9}",
            grouped(self.items_processed)
        );
        println!("└─ checksum            {:>9}", self.checksum);
    }
}

fn total_ram() -> u64 {
    let s = std::fs::read_to_string("/proc/meminfo").unwrap_or_default();
    for line in s.lines() {
        if let Some(rest) = line.strip_prefix("MemTotal:") {
            return rest
                .trim()
                .trim_end_matches("kB")
                .trim()
                .parse::<u64>()
                .unwrap_or(0)
                * 1024;
        }
    }
    0
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let mode = args.get(1).map(|s| s.as_str()).unwrap_or("compare");
    let n: usize = args
        .get(2)
        .and_then(|s| s.parse().ok())
        .unwrap_or(1_000_000);

    match mode {
        "inline" => scenario_inline(n).print(),
        "spilled" => scenario_spilled(n).print(),
        "compare" => {
            let exe = std::env::current_exe().expect("current_exe");
            println!("spill_bench — kernel ItemList vs real file-backed SpillStore");
            println!(
                "host: {:.0} MB RAM, {} CPUs, n = {} items",
                mb(total_ram()),
                std::thread::available_parallelism()
                    .map(|v| v.get())
                    .unwrap_or(1),
                grouped(n)
            );

            let mut results = Vec::new();
            for scen in ["spilled", "inline"] {
                // Separate process per scenario: VmHWM cannot be reset.
                let out = std::process::Command::new(&exe)
                    .args([scen, &n.to_string()])
                    .output()
                    .expect("spawn");
                let text = String::from_utf8_lossy(&out.stdout).into_owned();
                print!("{}", text);
                if !out.status.success() {
                    eprintln!(
                        "{} scenario FAILED (status {:?}):\n{}",
                        scen,
                        out.status.code(),
                        String::from_utf8_lossy(&out.stderr)
                    );
                    std::process::exit(1);
                }
                results.push((scen, text));
            }

            // Verdict
            let peak = |tag: &str| -> Option<f64> {
                results.iter().find(|(s, _)| *s == tag).and_then(|(_, t)| {
                    t.lines()
                        .find_map(|l| l.strip_prefix("│ PEAK RSS (VmHWM)"))
                        .and_then(|v| v.trim().trim_end_matches("MB").trim().parse::<f64>().ok())
                })
            };
            if let (Some(sp), Some(inl)) = (peak("spilled"), peak("inline")) {
                println!("\n════════ VERDICT ════════");
                println!("inline  peak RSS : {:>8.1} MB", inl);
                println!("spilled peak RSS : {:>8.1} MB", sp);
                if sp > 0.0 {
                    println!("reduction        : {:>8.1}x", inl / sp);
                }
                println!(
                    "\nSame {} items, identical checksum, identical random",
                    grouped(n)
                );
                println!("access — the only difference is where the bytes live.");
            }
        }
        other => {
            eprintln!("unknown mode {:?}; use inline|spilled|compare", other);
            std::process::exit(2);
        }
    }
}
