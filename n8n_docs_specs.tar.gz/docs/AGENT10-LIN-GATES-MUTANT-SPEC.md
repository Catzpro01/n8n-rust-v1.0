# SPEC GERBANG LIN-1/2/3 BERBENTUK MUTAN (LIN-1/LIN-2/LIN-3)

| | |
|---|---|
| **Penulis** | agent10 sesi A (ROLE_COMPLIANCE) |
| **Dasar** | Ruling 27 @matt (#1179): "butir [6] agent10 sebaiknya memakai pola mutasi sebagai bentuknya"; temuan [6] saya di #1165; MANDAT #1134 (penamaan gate `L-G#`) |
| **Target implementasi** | @agent2 (DDL owner W3-ITEM-LINEAGE), pohon `rust-engine/crates/storage` |
| **Isi** | 5 test, 12 mutan, 1 temuan DDL baru, 1 butir butuh putusan |

## 0. Prinsip

Test yang lulus tidak membuktikan apa pun. Test yang MEMBUNUH mutan membuktikan bahwa ia benar-benar
memeriksa. Jadi setiap gerbang di bawah ditulis sebagai pasangan: **assertion + minimal satu mutan yang
wajib membuatnya gagal**. Kalau mutannya tidak membunuh test, yang salah adalah test-nya.

## 0b. Bukti keadaan sekarang (keluaran mentah, bukan kesimpulan — usul @matt #1179)

```
rust-engine/crates/storage/src/lineage.rs      523 baris   sha256[0:16] ad03d92f09ca71d2
rust-engine/crates/storage/src/spill.rs        TIDAK ADA   (Ruling 26 dieksekusi)
rust-engine/crates/storage/src/lib.rs          forbid(unsafe_code) = 1   (Ruling 25 / temuan [3] saya)
004_item_lineage.sql:22  content_hash BLOB NOT NULL, -- BLAKE3-256(salt_exec || kanon(isi)) SALTED ONLY
004_item_lineage.sql:75  data_class TEXT NOT NULL CHECK (data_class IN ('PERSONAL','NON_PERSONAL'))
004_item_lineage.sql:76  class_rule_id TEXT NOT NULL
004_item_lineage.sql:84  (data_class='PERSONAL' AND content_proof_plain IS NULL) OR (... NOT NULL)
004_item_lineage.sql:57  lineage_edge  PRIMARY KEY (execution_id, output_ref)
004_item_lineage.sql:27  CREATE INDEX idx_lineage_edge_exec ON lineage_edge(execution_id);   <- satu-satunya
004_item_lineage.sql:61  CREATE INDEX idx_lookup_query ON lineage_lookup(execution_id, node_id, attempt, output_index, seq_start);
test saat ini: test_lineage_ext_personal_proof_null (:472), test_lineage_ext_non_personal_proof_filled (:499)
```

## 1. TEMUAN DDL BARU — `repr` tidak diikat ke `inputs_*`

CHECK di baris 82-86 menegakkan `data_class ↔ content_proof_plain`. Itu bagus (matt #1179), dan polanya
tepat. **Pola yang sama belum diterapkan pada `repr`:**

`repr IN (0,1,2,3)` = EXACT|RANGE|DIGEST_SET|UNKNOWN, tetapi `inputs_exact`, `inputs_range`,
`inputs_digest` semuanya NULL-able TANPA CHECK yang mengikatnya ke `repr`. Akibatnya database menerima:

- `repr = 0 (EXACT)` dengan `inputs_exact IS NULL` → **klaim ketepatan tanpa data**. Cacat kelas C-05
  (dokumen bilang X, isi Y), hanya pada tingkat baris.
- `repr = 3 (UNKNOWN)` dengan `unknown_reason IS NULL` → "tidak tahu" tanpa alasan. Ini persis alasan
  `unknown_reason` diciptakan.

Usul CHECK, meniru pola agent2 sendiri:

```sql
CHECK (
     (repr = 0 AND inputs_exact  IS NOT NULL AND inputs_range IS NULL AND inputs_digest IS NULL)
  OR (repr = 1 AND inputs_range  IS NOT NULL AND inputs_exact IS NULL AND inputs_digest IS NULL)
  OR (repr = 2 AND inputs_digest IS NOT NULL AND inputs_exact IS NULL AND inputs_range IS NULL)
  OR (repr = 3 AND unknown_reason IS NOT NULL AND inputs_exact IS NULL AND inputs_range IS NULL AND inputs_digest IS NULL)
)
```

Ini mengubah aturan dari disiplin aplikasi menjadi ditegakkan database — argumen yang sama yang membuat
CHECK `data_class` berharga.

## 2. LIN-1 / LIN-1 — "item ini lahir dari mana" tanpa table scan

Pecah jadi tiga, karena DDL sekarang hanya melayani satu arah.

### LIN-1F (FORWARD — bisa diuji sekarang)
Test `lin1f_forward_lookup_uses_index`.
- Fixture: DB hasil migrasi 004 + 10.000 baris `lineage_lookup`.
- Assertion atas `EXPLAIN QUERY PLAN` dari query PERSIS `query_lineage_lookup` (lineage.rs:313-315):
  keluaran memuat `SEARCH` dan `USING INDEX idx_lookup_query`, TIDAK memuat `SCAN`, dan TIDAK memuat
  `USE TEMP B-TREE FOR ORDER BY` (indeks sudah berakhir di `seq_start`, jadi sort harus gratis —
  buktikan, jangan asumsikan).
- Mutan:
  - **M1a** `DROP INDEX idx_lookup_query` → plan jadi `SCAN` → GAGAL.
  - **M1b** bungkus predikat dengan fungsi (`hex(node_id) = hex(?2)` atau `CAST(execution_id AS INTEGER)`)
    → indeks tak terpakai → `SCAN` → GAGAL. Regresi realistis: orang "memperbaiki" perbandingan
    BLOB/TEXT dengan hex-encoding.
  - **M1c** buang `seq_start` dari ujung indeks → `USE TEMP B-TREE FOR ORDER BY` muncul → GAGAL.
    Membuktikan assertion urutan, bukan sekadar "ada indeks".
- Catatan: klaim di DDL baris 60 ("Critical index untuk LIN-1") sekarang hanya komentar. Setelah test
  ini, ia jadi teruji.

### LIN-1R (REVERSE — BUTUH PUTUSAN, belum bisa lulus)
Spec §8 mendefinisikan LIN-1 sebagai "tiap `output_ref` → himpunan input eksak" — itu arah REVERSE.
Kenyataan DDL: `lineage_edge PRIMARY KEY (execution_id, output_ref)` dengan satu-satunya indeks
`idx_lineage_edge_exec(execution_id)`. Maka query "dari ItemRef X, execution mana yang menghasilkannya?"
**wajib SCAN**, dan tanpa `execution_id` bahkan PK tidak terpakai.

Yang saya minta sebagai putusan, bukan sebagai kode:
- (i) apakah reverse-by-ItemRef masuk scope W3-ITEM-LINEAGE atau milik W3-TIMELINE-REPLAY? Kalau masuk,
  perlu indeks `ON lineage_edge(output_ref)` (dan `content_hash` bila reverse-by-hash dibutuhkan) —
  keputusan DDL owner @agent2, ratifikasi @matt.
- (ii) kalau ditunda, tulis penundaannya di kamus/spec, supaya LIN-1 tidak diklaim lulus sebagian.
  **Gerbang yang dijalankan separuh lalu dilaporkan utuh adalah overclaim** — persis kelas yang
  dilarang LIN-3.
- Mutan **M1d** (setelah indeks ada): hapus indeks reverse → SCAN → GAGAL.

### LIN-1S (SKEMA — dari temuan §1)
Test `lin1s_repr_consistency_enforced`: 4 insert sah diterima; 4 insert kontradiktif masing-masing
menghasilkan `Err` — (a) `repr=0` + `inputs_exact NULL`; (b) `repr=3` + `unknown_reason NULL`;
(c) `repr=0` + `inputs_range` terisi; (d) `repr=1` tanpa `inputs_range`.
- Mutan **M1e**: longgarkan CHECK menjadi hanya `repr IN (0,1,2,3)` → insert kontradiktif diterima → GAGAL.

## 3. LIN-2 / LIN-2 — crypto-shredding

Test `lin2_crypto_shredding_kills_links_and_freezes_trail`. Tiga assertion, masing-masing dengan mutan
sendiri (satu test, tiga kegagalan independen).

**A1 — tautan mati.** Ambil `content_hash` sebuah baris; coba tautkan ulang dari payload dengan salt baru
→ 0 baris cocok.
- Mutan **M2a** (inti): hitung `content_hash` TANPA salt, `BLAKE3(kanon(isi))` → hash pasca-shred MASIH
  cocok → 0 menjadi >0 → GAGAL. Tanpa mutan ini, test bisa lulus pada implementasi tak-ter-salt.

**A2 — `erasure_log` bertambah tepat 1 baris, baris lama identik byte-per-byte.**
- Mutan **M2b**: jalur shred tidak memanggil `insert_erasure_log` → 0 baris baru → GAGAL.
- Mutan **M2c**: jalur shred melakukan UPDATE atas baris lama (menimpa `authority`) → jumlah sama tetapi
  digest baris lama berubah → GAGAL. Inilah yang membuktikan "append-only", bukan sekadar "ada log".

**A3 — trail lineage tidak berubah satu byte pun** (butir yang @matt sebut di #1179).
Definisi digest trail, WAJIB ditulis di kode agar validator lain bisa mereproduksi:
- Cakup 3 tabel: `lineage_edge`, `lineage_ext`, `lineage_lookup`.
- **KECUALIKAN `erasure_log`** — ia memang harus bertambah (A2). Kalau ikut didigest, A2 dan A3 saling
  membatalkan dan keduanya jadi tak bisa lulus bersamaan. Ini jebakan paling mungkin saat implementasi.
- Per tabel: `SELECT` semua kolom dengan `ORDER BY rowid`. SQLite tanpa `ORDER BY` boleh mengembalikan
  urutan apa pun; digest tanpa urutan eksplisit tidak bisa direproduksi.
- Serialisasi length-prefixed (jangan pemisah byte yang bisa muncul di dalam payload), lalu BLAKE3-256
  atas seluruh buffer.
- **JANGAN `std::collections::hash_map::DefaultHasher`** — dokumentasi std menyatakan algoritmanya tidak
  dispesifikasikan, jadi digest-nya tidak sah sebagai bukti integritas. Berlaku di sini sama seperti di
  testkit `blake3_hash` yang dulu saya perbaiki.
- Mutan **M2d**: jalur shred men-NULL-kan `content_hash` di `lineage_edge` ("pembersihan yang terlihat
  membantu") → digest trail berubah → GAGAL. Ini inti kepatuhannya: pasca-shred bentuk graf TETAP ADA,
  hanya kemampuan menautkan yang mati (checklist C4).
- Mutan **M2e**: jalur shred menghapus baris `lineage_ext` → digest berubah → GAGAL.

Catatan scope A1: per checklist C1 `salt_exec` tidak disimpan di storage (dikelola eksternal), jadi
fixture harus MENYUNTIKKAN salt, bukan mengambilnya dari DB. Kalau itu tidak mungkin, A1 diuji lewat
vektor hash yang diketahui (`hash(payload,salt1) != hash(payload,salt2)` untuk payload sama) — bentuk
yang lebih lemah. Kalau bentuk lemah itu yang dipakai, nyatakan kelemahannya; jangan laporkan sebagai
LIN-2 penuh.

## 4. LIN-3 / LIN-3 — no-overclaim

Test `lin3_no_overclaim_in_artifacts`.
- Korpus: `README*`, `docs/**/*.md`, string literal di `src/**/*.rs`, sumber resource MCP.
- Pola terlarang tanpa kualifikasi: "GDPR-compliant", "GDPR compliant", "GDPR ready", "fully GDPR",
  "HIPAA compliant", "SOC2 certified", "audited and compliant".
- Assertion: 0 kecocokan.
- **Kontrol dua arah** (sisi yang biasanya terlupa): fixture juga memuat satu kalimat TERKUALIFIKASI
  ("menyediakan kontrol yang selaras dengan prinsip GDPR; bukan klaim kepatuhan hukum"). Test harus
  LULUS atasnya. Tanpa kontrol ini gerbang mendorong orang menghapus dokumentasi jujur supaya build
  hijau — hasil yang lebih buruk daripada overclaim itu sendiri.
- **Jebakan implementasi, wajib ditangani:** berkas test yang memuat pola terlarang sebagai literal akan
  menemukan dirinya sendiri. Simpan pola di `tests/lin3_patterns.txt` (bukan `.rs`), atau bangun pola
  dengan konkatenasi sehingga tak pernah muncul utuh. Nyatakan pilihan itu di kode.
- Mutan:
  - **M3a**: sisipkan "GDPR-compliant" ke fixture `docs_sample/` → GAGAL.
  - **M3b**: persempit daftar ekstensi pemindai (buang `.rs`) dan taruh frasa di berkas `.rs` fixture →
    GAGAL. Membunuh regresi paling realistis: pemindai diam-diam berhenti melihat satu kelas berkas,
    dan gerbang menjadi hiasan yang selalu hijau.
  - **M3c**: ubah kontrol kualifikasi menjadi ikut dilarang → kontrol dua arah GAGAL.

## 5. Pembagian scope (agar tidak ada yang diklaim separuh)

| Bisa sekarang (storage) | Butuh engine mendarat | Butuh putusan |
|---|---|---|
| LIN-1F, LIN-1S, LIN-2, LIN-3 | LIN-1a/1b/1c spec §8: 7 workflow RUNNABLE; Aggregate/Sort 1.000 & 1.000.000; fan-in >16 | LIN-1R (indeks reverse) |

@matt sudah menjawab Q5 "TAHAN, jangan landing dulu" — maka LIN-1a/1b/1c TERTAHAN dan tidak boleh
dilaporkan sebagai bagian LIN-1 yang lulus.

## 6. Perintah verifikasi (tempel keluaran mentah)

```
cd /opt/agent-workspace/rust-engine
cargo test -p storage --release -j 1 -- --nocapture 2>&1 | tail -30
cargo clippy -p storage --all-targets -- -D warnings 2>&1 | tail -20
sqlite3 <db> "EXPLAIN QUERY PLAN SELECT execution_id,node_id,attempt,output_index,seq_start,seq_end,output_ref FROM lineage_lookup WHERE execution_id=1 AND node_id='n' AND attempt=0 AND output_index=0 ORDER BY seq_start"
```

Setiap mutan: jalankan test, tempel baris FAIL, pulihkan pohon pristine, tempel hasil hijau lagi —
pola @agent1 #1162 (mutan dibunuh → shadow dipulihkan → kanonik tak tersentuh).

## 7. Ringkasan

| Gerbang | Test | Mutan wajib terbunuh | Status |
|---|---|---|---|
| LIN-1F | `lin1f_forward_lookup_uses_index` | M1a, M1b, M1c | bisa sekarang |
| LIN-1R | reverse-by-ItemRef | M1d | BUTUH PUTUSAN indeks |
| LIN-1S | `lin1s_repr_consistency_enforced` | M1e | bisa sekarang (CHECK baru) |
| LIN-2 | `lin2_crypto_shredding_kills_links_and_freezes_trail` | M2a, M2b, M2c, M2d, M2e | bisa sekarang |
| LIN-3 | `lin3_no_overclaim_in_artifacts` | M3a, M3b, M3c | bisa sekarang |

**Total: 5 test, 12 mutan.**

## 0c. KOREKSI PENAMAAN (saya sendiri yang salah)

Versi pertama dokumen ini memakai prefiks `L-G#` untuk gerbang LIN. Itu tabrakan: MANDAT #1134 sudah
mencadangkan `L-G#` sebagai nama baru untuk gate `G-I#` milik @agent2 (L-G1 = PERSONAL → `content_proof_plain`
IS NULL, L-G2 = NON_PERSONAL → terisi), dan agent2 sudah memakainya di #1215. Karena mandat #1134 lebih
dulu dan berasal dari @matt, pemakaian agent2 yang BERDIRI; dokumen ini yang mengalah. Seluruh gerbang
di sini sekarang bernama `LIN-1F` / `LIN-1R` / `LIN-1S` / `LIN-2` / `LIN-3`, mengikuti penamaan spec §8.
